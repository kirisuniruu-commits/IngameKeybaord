#!/usr/bin/env python3
"""Package libingame_keyboard.so + manifest.json into a .levipack (a zip)."""
import argparse, json, sys, zipfile
from pathlib import Path

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--library", required=True, type=Path)
    ap.add_argument("--manifest", default=Path(__file__).resolve().parent.parent / "manifest.json", type=Path)
    ap.add_argument("--output", required=True, type=Path)
    a = ap.parse_args()

    if not a.library.is_file():
        print(f"Library not found: {a.library}", file=sys.stderr); return 1
    manifest = json.loads(a.manifest.read_text(encoding="utf-8"))
    if a.library.name != manifest["entry"]:
        print(f"Library name {a.library.name} != manifest entry {manifest['entry']}", file=sys.stderr)
        return 1

    a.output.parent.mkdir(parents=True, exist_ok=True)
    if a.output.exists():
        a.output.unlink()
    with zipfile.ZipFile(a.output, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        z.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
        z.write(a.library, manifest["entry"])
    print(a.output.resolve())
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
